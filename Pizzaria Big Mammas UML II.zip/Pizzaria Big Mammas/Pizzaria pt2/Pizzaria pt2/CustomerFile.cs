﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzaria_pt2
{
    public class CustomerFile
    {
        private static List<Kunder> kunderliste = new List<Kunder>();

        public static void CreateKunder(Kunder Kunder)
        {
            kunderliste.Add(Kunder);
        }

        public static void CreateKunder(string name, string email, string adresse, string phoneNo)
        {
            kunderliste.Add(new Kunder(name, email, adresse, phoneNo));
        }

        public static Kunder ReadKunderbyId(int id)
        {
            foreach (Kunder Kunder in kunderliste)
            {
                if (Kunder.Id == id)
                {
                    Console.WriteLine(Kunder);
                    return Kunder;
                }
            }
            Console.WriteLine("No Customer found");
            return null;
        }

        public static void UpdateKunde(int id, Kunder customer)
        {
            foreach (Kunder kunder in kunderliste)
            {
                if (kunder.Id == id)
                {
                    id = customer.Id;
                    kunder.AddressKunde = customer.AddressKunde;
                    kunder.NameKunde = customer.NameKunde;
                    kunder.Emailkunde = customer.Emailkunde;
                }
            }
            Console.WriteLine("Updating Customers Informations....");
        }
        public static Kunder RemoveKunderById(int id)
        {
            foreach (Kunder kunder in kunderliste)
            {
                if (kunder.Id == id)
                {
                    kunderliste.Remove(kunder);
                    Console.WriteLine($"Kunde {kunder.NameKunde} has been deleted");
                    return kunder;
                }

            }

            return null;
        }

        public static void PrintMenu()
        {
            foreach (Kunder kunder in kunderliste)
            {
                Console.WriteLine(kunder);
            }
        }


    }
}   
