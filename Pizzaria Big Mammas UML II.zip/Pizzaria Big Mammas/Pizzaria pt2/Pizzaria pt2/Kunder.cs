﻿     public class Kunder
     {
        public static int nextId = 1;
        public Kunder()
        {
            Id = nextId++;
        }
        public Kunder(string nameKunde, string addressKunde, string phoneNumberKunde, string emailkunde)
        {
            Id = nextId++;
            NameKunde = nameKunde;
            AddressKunde = addressKunde;
            PhoneNumberKunde = phoneNumberKunde;
            Emailkunde = emailkunde;
        }
             public int Id { get; set; }
             public string NameKunde { get; set; }
             public string AddressKunde { get; set; }
             public string PhoneNumberKunde { get; set; }
             public string Emailkunde { get; set; }

          public override string ToString()
    {
        return "Kundens Id er: " + Id + " " + "Kundens navn er: " + NameKunde + " " + "Adresse: " + AddressKunde + " " + "Email: " + Emailkunde + " " + "TelefonNummer: " + PhoneNumberKunde;
    }
}
