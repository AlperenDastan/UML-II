﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzaria_pt2
{
    public class PizzaMenu
    {
        private static Dictionary<int, Pizza> pizzaList = new Dictionary<int, Pizza>();

        public int Count
        {
            get { return pizzaList.Count; }
        }

        public static void CreatePizza(Pizza pizza)
        {
            if (pizzaList.ContainsKey(pizza.id))
            {
                Console.WriteLine($"Pizza already an item");
            }
            else
            {
                pizzaList.Add(pizza.id, pizza);
                Console.WriteLine(@"Pizza added");
            }
        }
        public static void LookupPizza(int id)
        {
            if (pizzaList.ContainsKey(id))
            {
                Console.WriteLine($"Pizza found:{pizzaList[id]}");
            }
            else
            {
                Console.WriteLine("Pizza not found");
            }
        }
        public static void UpdatePizza(int id, string NewName, string NewDescription, int NewPrice)
        {
            pizzaList[id].prisPizza = NewPrice;
            pizzaList[id].namePizza = NewName;
            pizzaList[id].indholdPizza = NewDescription;
            Console.WriteLine("Pizza Updated");
        }
        public static void DeletePizza(int id)
        {
            if (pizzaList.ContainsKey(id))
            {
                Console.WriteLine($"Pizza has been deleted; {pizzaList[id]}");
            }
            else
            {
                Console.WriteLine("No Pizza has been deleted");
            }
        }

        public static void PrintMenuPizza()
        {
            foreach (var pizza in pizzaList)
            {
                Console.WriteLine(pizza);
            }
        }
    }
    
}
