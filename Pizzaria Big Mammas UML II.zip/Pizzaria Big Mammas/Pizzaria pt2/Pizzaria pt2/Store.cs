﻿namespace Pizzaria_pt2
{
    internal class store
    {
        public void start()
        {
            Pizza pizza1 = new Pizza("Pepperoni Pizza", "Ost, Tomatsovs, Pepperoni. ", 90);
            Pizza pizza2 = new Pizza("Kennis Pizza", "Ost, Tomatsovs, salat, dressing, kebab, kylling, tomat, agurk, chili. ", 120);
            Pizza pizza3 = new Pizza("Olivers Pizza", "Ost, tomatsovs, ananas, skinke. ", 80);

            Kunder kunde1 = new Kunder("Mikhail", "4300 Holbæk", "52906931", "Tatlises@live.dk");
            Kunder kunde2 = new Kunder("Zaen", "2635 Ishøj", "81326469", "Cinderella@hotmail.com");
            Kunder kunde3 = new Kunder("Deniz", "4600 Køge", "31316969", "Saddike@hotmail.dk");
          

            //Ordre ordre1 = new Ordre(1, pizza1, kunde1);
            //Ordre ordre2 = new Ordre(2, pizza2, kunde2);
            //Ordre ordre3 = new Ordre(3, pizza3, kunde3);


            //Opretter kunden i listen
            CustomerFile.CreateKunder(kunde1);
            CustomerFile.CreateKunder(kunde2);
            CustomerFile.CreateKunder(kunde3);

            CustomerFile.PrintMenu();

            kunde1.Id = 1;
            kunde1.NameKunde = "Mikail Karlsen";
            kunde1.AddressKunde = "4600 Køge";
            kunde1.Emailkunde = "Tatlises@live.dk";

            kunde2.Id = 2;
            kunde2.NameKunde = "Zaen Olsen";
            kunde2.AddressKunde = "4300 Holbæk";
            kunde2.Emailkunde = "Cinderella@hotmail.com";

            kunde3.Id = 3;
            kunde3.NameKunde = "Deniz Christensen";
            kunde3.AddressKunde = "2635 Ishøj";
            kunde3.Emailkunde = "Saddike@hotmail.dk";
            CustomerFile.UpdateKunde(1, kunde1);
            CustomerFile.UpdateKunde(2, kunde2);
            CustomerFile.UpdateKunde(3, kunde3);
            //Opdaterer kundens informationer
        
            //læser kundens nye informationer op
            //CustomerFile.ReadKunderbyId(1);
            //CustomerFile.ReadKunderbyId(2);
            //CustomerFile.ReadKunderbyId(3);
          

            //Printer hele kunde menuen ud. 
            CustomerFile.PrintMenu();

            //Sletter kunden/kunderne
            CustomerFile.RemoveKunderById(1);
            CustomerFile.RemoveKunderById(2);
            CustomerFile.RemoveKunderById(3);

            Console.WriteLine();

            //Opretter pizzaen i systemet eller registrere den
            PizzaMenu.CreatePizza(pizza1);
            //Opdaterer pizzaen med nyt indhold, nyt navn, ny pris. Systemet generer et nyt ID til pizzaen 
            PizzaMenu.UpdatePizza(0, "BigBangPizza", "Tomatsovs, Ost, kebab, kylling, skinke, falafel", 250);
            //Sletter pizzaen fra menuen.
            PizzaMenu.DeletePizza(0);
            //Printer pizzamenuen ud.
            PizzaMenu.PrintMenuPizza();
            

            //Console.WriteLine(pizza1);
            //Console.WriteLine(pizza2);
            //Console.WriteLine(pizza3);

            //Console.WriteLine();

            //Console.WriteLine(kunde1);
            //Console.WriteLine(kunde2);
            //Console.WriteLine(kunde3);

            //Console.WriteLine();

            //Console.WriteLine(ordre1);
            //Console.WriteLine(ordre2);
            //Console.WriteLine(ordre3);
        }
    }
}
